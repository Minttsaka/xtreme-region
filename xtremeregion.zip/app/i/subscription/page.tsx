import SubscriptionPage from '@/components/payments/SubscriptionPage'
import React from 'react'

export default function page() {
  return (
    <div>
        <SubscriptionPage />
      
    </div>
  )
}
