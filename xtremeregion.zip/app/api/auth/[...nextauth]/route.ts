import { handlers } from "@/app/authhandlers/auth";

export const { GET, POST } = handlers;