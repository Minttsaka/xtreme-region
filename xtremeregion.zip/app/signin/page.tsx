

import { SigninForm } from '@/components/authentication/SigninForm'
import React from 'react'

export default async function page() {



  return (
    <div>
        <SigninForm />
    </div>
  )
}
