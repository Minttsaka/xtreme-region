
import SignupPage from '@/components/authentication/SignupForm'
import React from 'react'

export default function page() {
  return (
    <div>
      <SignupPage />
    </div>
  )
}
