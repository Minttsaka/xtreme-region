


export default function TrustedBy1() {
  return (
    <section className="container mt-10">
      <div className="text-center">
        <h2 className="text-lg  tracking-tight underline text-green-400">
          Trusted by <span >industry</span> leaders
        </h2>
      </div>
    </section>
  )
}

